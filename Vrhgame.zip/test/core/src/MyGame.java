
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;

class Game extends ApplicationAdapter {

    private OrthographicCamera camera;
    private Box2DDebugRenderer debugRenderer;
    private World world;
    private Body body;
    public double b;
    public double a;
    public float x;
    public float y;


    @Override
    public void create() {
        float w = Gdx.graphics.getWidth();
        float h = Gdx.graphics.getHeight();

        camera = new OrthographicCamera();
        camera.setToOrtho(false, w, h);

        this.world = new World(new Vector2(0, -9.8f), false);
        this.world.setContactListener(new beginonContact());
        debugRenderer = new Box2DDebugRenderer();

        a = System.currentTimeMillis();
        createPlayer();
        floor();
    }

    private void createPlayer() {
        Body playerBody;
        BodyDef def = new BodyDef();
        def.type = BodyDef.BodyType.DynamicBody;
        def.position.set(60, 450);
        playerBody = world.createBody(def);

        CircleShape shape = new CircleShape();
        shape.setRadius(10);

        x = playerBody.getPosition().x;

        FixtureDef fixtureDefb = new FixtureDef();
        fixtureDefb.shape = shape;
        fixtureDefb.density = 1.0f;

        this.body = world.createBody(def);
        this.body.createFixture(fixtureDefb).setUserData(this);
        this.body.setLinearVelocity(20, 0);

        shape.dispose();
    }

    private void floor() {
        BodyDef bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.StaticBody;
        bodyDef.position.set(200, -400);
        Body result = world.createBody(bodyDef);

        PolygonShape shape = new PolygonShape();
        shape.setAsBox(500, 450);

        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        fixtureDef.density = 1.0f;

        this.body = world.createBody(bodyDef);
        this.body.createFixture(fixtureDef).setUserData(this);

        result.createFixture(shape, 1f);
        shape.dispose();
    }

    @Override
    public void render() {
        Gdx.gl.glClearColor(0f, 0f, 0f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        world.step(1 / 60f, 6, 2);
        debugRenderer.render(world, camera.combined);
    }

    @Override
    public void resize(int width, int height) {
        camera.setToOrtho(false, width, height);
    }

    @Override
    public void dispose() {
        world.dispose();
        debugRenderer.dispose();
    }


    public class beginonContact implements ContactListener {
        @Override
        public void beginContact(Contact contact) {
            Fixture fa = contact.getFixtureA();
            Fixture fb = contact.getFixtureB();

            if (fa == null || fb == null) return;
            if (fa.getUserData() == null || fb.getUserData() == null) return;

            b = System.currentTimeMillis();
            y = fa.getDensity();

            System.out.println((b - a) / 1000 + " s");
            System.out.println((x - y) + " m");
            System.out.println("A collision happened");
        }

        @Override
        public void endContact(Contact contact) {

        }

        @Override
        public void preSolve(Contact contact, Manifold oldManifold) {

        }

        @Override
        public void postSolve(Contact contact, ContactImpulse impulse) {

        }
    }
}